package cse214hw1;

public class Main {
    public static void main(String[] args) {
        DoublyLinkedList<Integer> idll = new DoublyLinkedList<>();
        // idll.add(2);
        idll.add(4);
        System.out.println(idll.isEmpty());
        System.out.println(idll);
    }
}
